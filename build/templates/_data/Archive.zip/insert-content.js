    $(document).ready(function(){
            $.getJSON("demo_ajax.js", function(result){

                $.each(result, function(i, icon, title, description){
                    $("i.icon").append(icon),
                    $("p.title").append(title),
                    $("p.subtitle").append(description);
                });
            });
        });