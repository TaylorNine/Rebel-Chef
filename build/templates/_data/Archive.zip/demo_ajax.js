var content = [
    {icon: "hourglass",
    title: "Title 1", 
    description:"This is the area where a description would go."}
    {icon: "pointer", 
    title: "Second Title", 
    description:"The second descriptions"}
    {icon: "moon", 
    title: "Third Title For This", 
    description:"Check my third description on deeeeez nutz."}
]